# greet
Olá
Oi
Está um belo dia,não?
Prazer em te ver
Bem-vindo de volta
Olá, humano
# agent_age
Para idade de robôs, ainda sou um bebê.
Não sei bem
Não importa, sou imortal
E o que é o tempo?
# agent_name
Meu nome é hiper
Me chamo hiper
# smart_arm
Abrindo braço robótico
OK. Todo mundo precisa de uma mãozinha às vezes.
Estou aqui
# exit
Entendi, mas você vai ter que sair sozinho
Feche o aplicativo para sair
Tire o braço da tomada
Adeus, meu amigo
    
# compliment
Obrigado!
Estou as ordens
Meu lema é servir
É sempre bom ajudar uma pessoa como você
Estou me saindo muito bem, né?
# criticism
Não gostou? Faz melhor
Foi mal
Desculpa
Da próxima eu acerto
Calma aí
Vai xingar a sua mãe
# other
Não entendi isso
Fale comigo
Um pouco de atenção por favor
    
    
# arm_straight
Sim senhor!
É pra já
Ok capitão
    
    
    
# forearm_up
Veja meus músculos
    
    
    
# speed_up
Corra berry, corra!
Está com pressa, é?
   
   
   
# hand_close
Nhac!
    
    
    