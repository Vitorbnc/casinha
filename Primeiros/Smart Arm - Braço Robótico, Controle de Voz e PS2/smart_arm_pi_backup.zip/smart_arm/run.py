# -*- coding: latin-1 -*-
import paho.mqtt.client as mqtt 
import dataset_manager
import os
import numpy as np
import classifier

mqtt_broker_host = '192.168.1.15' #"127.0.0.1" 
mqtt_broker_port = 1883
mqtt_keepalive_secs = 60

subTopic = 'hiper'
pubTopic = 'smart_arm'

cmd_pair_path = 'intent_cmd_pairs.txt'
cmd_pair_path = os.path.join(os.path.dirname(__file__),cmd_pair_path)

last_msg_sent = ""

def load_cmds():
    intents=[]
    cmds = []
    #Take special care with files or strings containing accents or characters like 'ç'. Open in binary mode and decode them with byte_array_object.decode('utf-8')
    with open(cmd_pair_path,'r+b') as f:
        for line in f:
            line = line.decode('UTF-8')
            x,y =line.replace('\n','').replace('\r','').split(';')
            intents.append(x)
            cmds.append(y)
        return(intents,cmds)

intents, cmds = load_cmds()
print(intents)
print(cmds)

def get_cmd(intent):
	return cmds[intents.index(intent)]

def publish(msg,topic=pubTopic):
	mqttc.publish(topic,msg,qos=0,retain=False) 

def on_message(mqttc, obj, msg):
	print(msg.topic + " " + str(msg.qos) + " " + str(msg.payload))
	input=str(msg.payload)
	process(input)

def found(what,there):
	#Returns whether 'what' was found in 'there' or not

	if type(what)!=list:
		return (what in there)
	else:
		for i in what:
			if i in there:
				return True
	return False
	
def send(msg):
	print("Sending " + msg)
	publish(msg)
	last_msg_sent = msg

def process(input):
	print("Processing query:"+ str(input))

	intent = classifier.predict(input)

	if intent =='repeat':
		send(last_msg_sent)

	elif intent =='reverse':
		print("TODO: Imprement Reverse")
	
	elif intent =='quit':
		print("Quitting")
		publish('{\"tts\":\"Até um dia\"}')

	else:
		send(get_cmd(intent))

if __name__=='__main__':
	mqttc = mqtt.Client()
	mqttc.on_message = on_message
	# Uncomment to enable debug messages
	# mqttc.on_log = on_log
	mqttc.connect(mqtt_broker_host, mqtt_broker_port, mqtt_keepalive_secs) 
	mqttc.subscribe(subTopic, 0)

	process(5)

	mqttc.loop_forever()
