import dataset_manager
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import LinearSVC
from sklearn.linear_model import SGDClassifier

import pickle
import os

(data_train, y_train) = dataset_manager.load()
print(data_train)
print(y_train)
y_names =[]
[y_names.append(dataset_manager.get_label_name(i)) for i in y_train]
print(y_names)
dataset_manager.save(data_train,y_train)

model_path = 'model.bin'
model_path = os.path.join(os.path.dirname(__file__),model_path)

cv = CountVectorizer()
x_train = cv.fit_transform(data_train)

def build_classifier():
    clf = LinearSVC()
    clf.fit(x_train,y_train)
    return clf

def load_classifier():
    if os.path.exists(model_path):
        clf = pickle.load(open(model_path))
        return clf
    else:
         return build_classifier()

def save_classifier(model):
    with open(model_path,'w+b') as f:
        pickle.dump(model,f)

clf = load_classifier()
save_classifier(clf)

def predict(string_input):
    x = cv.transform([string_input])
    print(x)
    y = clf.predict(x)
    y = y[0]
    label = dataset_manager.get_label_name(y)
    print(label)
    return label

#predict("levanta a base")
    





