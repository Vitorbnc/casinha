import os
import pickle

train_data_path = 'data\\train_data.txt'
label_names_path = 'data\\label_names.txt'

pickled_data_train='data_train.bin'
pickled_y_train='y_train.bin'

current_dir = os.path.dirname(__file__)

train_data_path =os.path.join(os.path.dirname(__file__),train_data_path)
label_names_path = os.path.join(os.path.dirname(__file__),label_names_path)

pickled_data_train = os.path.join(os.path.dirname(__file__),pickled_data_train)
pickled_y_train = os.path.join(os.path.dirname(__file__),pickled_y_train)


def load_label_names():
    labels =[]
    with open(label_names_path) as f:
        [labels.append(line.replace('\n','').replace('\r','')) for line in f]
    return labels

label_names=[]
label_names = load_label_names()


def get_label_name(index):
    return label_names[index]

def load():
    if  os.path.exists(pickled_data_train) and os.path.exists(pickled_y_train):
        data_train = pickle.load(open(pickled_data_train,'r+b'))
        y_train = pickle.load(open(pickled_y_train,'r+b'))
        return (data_train,y_train)
    else:
        load_fresh()


def load_fresh():
    data_train=[]
    y_train = []
    #Take special care with files or strings containing accents or characters like 'ç'. Open in binary mode and decode them with byte_array_object.decode('utf-8')
    with open(train_data_path,'r+b') as f:
        for line in f:
            line = line.decode('UTF-8')
            x,y =line.replace('\n','').replace('\r','').split(';')
            y = label_names.index(y)
            data_train.append(x)
            y_train.append(y)
        return(data_train,y_train)


def save(data_train,y_train):
    data = open(pickled_data_train,'w+b')
    labels = open(pickled_y_train,'w+b')
    pickle.dump(data_train,data)
    pickle.dump(y_train,labels)
    data.close()
    labels.close()
    print('Train data saved')
