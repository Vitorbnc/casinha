package com.vitor.gatecontrol

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.util.Log
import android.widget.Toast
import com.mikepenz.iconics.Iconics.init
import java.io.IOException
import java.io.OutputStream
import java.util.*

/**
 * Created by vitor on 16/01/2018.
 */
class BtCommThread(btDevice: BluetoothDevice):Thread() {
   //Don't change this UUID, others won't work
   private var uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
   private val device = btDevice
   private var socket: BluetoothSocket
   private var adapter = BluetoothAdapter.getDefaultAdapter()
   private lateinit var outStream: OutputStream

    //init é o construtor primário do kotlin
    init{
        var tmp: BluetoothSocket? = null
        try {
            tmp = device.createInsecureRfcommSocketToServiceRecord(uuid)

        }   catch (e: IOException) {
            Log.w("socket","Socket Creation Failed")
        }

        //Returns the object or NPE
        socket = tmp!!

    }

    public fun isConnected():Boolean{
        return socket?.isConnected()
    }

    public override fun run(){
        if(adapter.isDiscovering)
                adapter.cancelDiscovery()
        try{
            socket.connect()
            outStream = socket.outputStream
        }catch(connectException:IOException){
            Log.w("connect","Can't establish connection with "+device.name.toString())
            closeSocket();
        }

    }

    public fun write(bytes:ByteArray){
        outStream.write(bytes)
    }

    public fun closeSocket(){
       try{
           socket.close()
       }
       catch (socketCloseFailed: IOException){
       }
    }
}