package com.vitor.gatecontrol

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.CompoundButton
import android.widget.Toast
import com.vitor.gatecontrol.R.id.txtDeviceName
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val REQUEST_ENABLE_BT = 125

    private val btCheckInterval:Long = 3000
    private val keepAliveMsgInterval:Long = 2000
    private lateinit var btAdapter: BluetoothAdapter
    private var btDeviceName = "VALHALLA"
    private lateinit var btDevice:BluetoothDevice

    private var btCommThread: BtCommThread? = null

    private var autoCloseEnabled = true
    private var wasOpened = false
    private var triedToEnableBt = false // Used to show message only on 1st time bluetooth is enabled
    private var userTriedToConnect = false // Used to show message only when user presses connect button
    private var userTriedToDisconnect = false // We will stop trying to connect if user disconnected
    private var isActive = false //Is set to false by onDestroy (like double tap return), prevents future events from happening after app is closed

    private val autoCloseDivisor = 3 //We'll send a message every time counter is multiple of this number
    private var autoCloseCounter  = autoCloseDivisor-1

    private val msgKeepAlive = "{kal}"
    private val msgSignal = "{btn}"
    private val msgAutoCloseDisabled = "{acd}"
    private val msgAutoCloseEnabled = "{ace}"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //null if there's no Bt support
        btAdapter = BluetoothAdapter.getDefaultAdapter()

        autoCloseEnabled = swAutoClose.isChecked


        swAutoClose.setOnCheckedChangeListener{buttonView, isChecked ->
            autoCloseEnabled = isChecked
            autoCloseCounter = autoCloseDivisor //Will speed up message sending when connected

        }

        //Enable Bluetooth on Create
        enableBt()

        var mainHandler = Handler()
        checkBtConnection(mainHandler)
        sendKeepAlive(mainHandler)

        isActive = true


    }

    override fun onStart() {
        super.onStart()
        //Connect On Start, ie when activity gets fullscreen
        //connect()
    }


    override fun onDestroy() {
        super.onDestroy()
        isActive = false
        //Disconnect on Destroy
        //if(isConnected())
           //btCommThread?.closeSocket()
        disableBt();
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ENABLE_BT){
            if(resultCode== Activity.RESULT_OK)
                connect()

            }

        }


    private fun connect(){
        if(!isActive) return
        if(!btAdapter.isEnabled) {
            enableBt()
            return
        }
        if(isConnected())
            return

        if (!getBtDevice(btDeviceName)) {
            //Only show messages if user tried connection
            if (userTriedToConnect) Toast.makeText(this, "Dispositivo não encontrado", Toast.LENGTH_SHORT).show()
        }
        else{
            if(userTriedToConnect) Toast.makeText(this,"Conectando...",Toast.LENGTH_SHORT).show()

            btCommThread = BtCommThread(btDevice)
            //Use start() and don't use run()! Start is non blocking, calling run is blocking, this the thread gets useless
            btCommThread!!.start()
        }
    }

    private fun enableBt() {
        if (!btAdapter.isEnabled) {
            if (!triedToEnableBt) {
                Toast.makeText(this, "Habilitando Bluetooth", Toast.LENGTH_SHORT).show()
                triedToEnableBt = true
            }
            //enableBtIntent() //This will ask for permission every time
            btAdapter.enable()
        }
    }

    private fun enableBtIntent(){
        var enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
        startActivityForResult(enableBtIntent,REQUEST_ENABLE_BT)
    }

    private fun disableBt(){
        if(btAdapter.isEnabled)
            btAdapter.disable()
    }

    private fun isConnected():Boolean{
        if(!btAdapter.isEnabled or !isActive) return false
        if(btCommThread != null)
            return btCommThread!!.isConnected()
        else return false
    }

    private fun checkBtConnection(handler:Handler){

        if(isConnected()) {
            txtConnectionStatus.text = getString(R.string.connected)
            btnConnect.text = getString(R.string.disconnect)
            //Auto open on 1st connect
           /* if(!wasOpened) {
                btCommThread?.write(msgSignal.toByteArray())
                wasOpened = true;
            }
            */
        }
        else {
            txtConnectionStatus.text = getString(R.string.disconnected)
            btnConnect.text = getString(R.string.connect)
            if(!userTriedToDisconnect) connect()
        }

        handler.postDelayed({checkBtConnection(handler)},btCheckInterval)
    }

    fun getBtDevice(name:String):Boolean{
        var pairedDevices = btAdapter.bondedDevices
        Log.d("device",pairedDevices.toString())
        for (device:BluetoothDevice in pairedDevices){

            if(device.name.toString()==name){
                btDevice = device
                return true
            }
        }
        return false
    }

    fun sendKeepAlive(handler: Handler){
        //Sends keepalive messages (always sends when device is connected) and autoclose enabled or disabled messages when required
        if(isConnected()) {
            if(autoCloseCounter.rem(autoCloseDivisor)==0) //Sends autoclose messages when counter is multiple of defined divisor
                if (autoCloseEnabled)
                    btCommThread?.write(msgAutoCloseEnabled.toByteArray())
                else
                    btCommThread?.write(msgAutoCloseDisabled.toByteArray())

            btCommThread?.write(msgKeepAlive.toByteArray())
            autoCloseCounter++
        }
        else
            autoCloseCounter = autoCloseDivisor-1

        handler.postDelayed({sendKeepAlive(handler)},keepAliveMsgInterval)

    }

    fun sendSignal(view: View){
         if(isConnected())
            btCommThread?.write(msgSignal.toByteArray())
    }

    fun toggleBtConnection(view:View){
        val txt = txtDeviceName.text.toString()
        if(txt=="") {
            Toast.makeText(this, "Nome inválido", Toast.LENGTH_SHORT).show()
            return
        }
        else
            btDeviceName = txt

        if(isConnected()) { //Disconnection intended
            userTriedToDisconnect = true
            userTriedToConnect = false
            btCommThread?.closeSocket() //Using ?. will return null if null

        }
        else { //Connection intended
            userTriedToConnect = true
            userTriedToDisconnect = false
            connect()
        }


    }

}
