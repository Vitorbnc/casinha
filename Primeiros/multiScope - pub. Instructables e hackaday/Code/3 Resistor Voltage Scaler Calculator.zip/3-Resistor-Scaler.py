Vcc = float(input("Choose Vcc:"))
Vmin = float(input("Choose minimum (must be negative) input Voltage:"))
if Vmin<0:
    Vmin=-Vmin

Vmax = float(input("Choose maximum input voltage:"))

def pickR3():
    global R3
    R3 = float(input("Choose R3 Value (kOhms):"))
    

def printResults():
    R2 = R3*Vcc/(Vmax-Vcc)
    R1 = R3*Vcc/Vmin
    Z_inv = (1/R1)+(1/R2)+(1/R3)
    Z = 1/Z_inv
    tmp = "R1 = "+str(R1)+"k"
    print(tmp)
    tmp = "R2 = "+str(R2)+"k"
    print(tmp)
    tmp ="Impedance(Z) = "+str(Z)+"k"
    print(tmp)

pickR3()
printResults()
rePick = input("Re-pick R3?")
if rePick=="yes" or rePick=="y":
    pickR3()
    printResults()




